##################################
##Random Forest Generator for	##
##Relative Enzymatic Activity	##
##Prediction - NAGLU			##
##Written By: Colby Ford, M.Sc.	##
##################################

##Must have randomForest package installed
#install.packages("randomForest")

##Microsoft Azure Machine Learning Initialization
#Define Datasets by Port
train <- maml.mapInputPort(1) #class: data.frame
test <- maml.mapInputPort(2) #class: data.frame

#Call the Library
library(randomForest)

#Get Probabilistic Complements
train$pph2_prob <- 1-train$pph2_prob
test$pph2_prob <- 1-test$pph2_prob

##Generate Prediction
forest <- randomForest(pph2_prob ~ Wt_nucleotide + Mut_nucleotide + AA_position + Wt_AA_name + Mut_AA_name + Wt_AA + Mut_AA + Mut_Codon_Pos + Wt_AA_type + Mut_AA_type + AATypeChange + Domain + allele1_freq,data = train,ntree = 25)
pred <- as.data.frame(predict(forest,test,type="response",predict.all=TRUE)
#Add Aggregate Prediction Score to Test Data
test$prediction <- pred$aggregate

#Calculate Standard Deviation for randomForest Trees and Add to Test Data
indiv <- pred
indiv$aggregate <- NULL
test$pred.sd <- apply(indiv,1,sd)

#Map Output to Azure ML Output Port
maml.mapOutputPort("test");

##################################
