#!/usr/bin/perl
use strict;
use warnings;

my $filename = 'prediction.txt';


open(FILE,$filename) || die "Cannot Open This File!\n";

open my $out_file, '>','result_prediction.txt';

while (<FILE>) {
    
my @data = split(/\t/,$_);

    
my $output = join "\t",$data[0],$data[6],$data[7],$data[8],$data[11],$data[14],$data[15],$data[16],$data[17],$data[18],"\n";

print $out_file $output;


}


close FILE;


