#!/usr/bin/perl

use strict;
use warnings;
my $input = 'MEAVAVAAAVGVLLLAGAGGAAGDEAREAAAVRALVARLLGPGPAADFSVSVERALAAKPGLDTYSLGGGGAARVRVRGSTGVAAAAGLHRYLRDFCGCHVAWSGSQLRLPRPLPAVPGELTEATPNRYRYYQNVCTQSYSFVWWDWARWEREIDWMALNGINLALAWSGQEAIWQRVYLALGLTQAEINEFFTGPAFLAWGRMGNLHTWDGPLPPSWHIKQLYLQHRVLDQMRSFGMTPVLPAFAGHVPEAVTRVFPQVNVTKMGSWGHFNCSYSCSFLLAPEDPIFPIIGSLFLRELIKEFGTDHIYGADTFNEMQPPSSEPSYLAAATTAVYEAMTAVDTEAVWLLQGWLFQHQPQFWGPAQIRAVLGAVPRGRLLVLDLFAESQPVYTRTASFQGQPFIWCMLHNFGGNHGLFGALEAVNGGPEAARLFPNSTMVGTGMAPEGISQNEVVYSLMAELGWRKDPVPDLAAWVTSFAARRYGVSHPDAGAAWRLLLRSVYNCSGEACRGHNRSPLVRRPSLQMNTSIWYNRSDVFEAWRLLLTSAPSLATSPAFRYDLLDLTRQAVQELVSLYYEEARSAYLSKELASLLRAGGVLAYELLPALDEVLASDSRFLLGSWLEQARAAAVSEAEADFYEQNSRYQLTLWGPEGNILDYANKQLAGLVANYYTPRWRLFLEALVDSVAQGIPFQQHQFDKNVFQLEQAFVLSKQRYPSQPRGDTVDLAKKIFLKYYPGWVAGSW';

$input =~ s/\s//g;
my @seq = split ('', $input);

my $count_of_A = 0;
my $count_of_C = 0;
my $count_of_S = 0;
my $count_of_T = 0;
my $count_of_P = 0;
my $count_of_G = 0;
my $count_of_N = 0;
my $count_of_D = 0;
my $count_of_E = 0;
my $count_of_Q = 0;
my $count_of_H = 0;
my $count_of_R = 0;
my $count_of_K = 0;
my $count_of_M = 0;
my $count_of_I = 0;
my $count_of_L = 0;
my $count_of_V = 0;
my $count_of_F = 0;
my $count_of_Y = 0;
my $count_of_W = 0;

    for my $AA (@seq) {
	if ($AA eq 'A' ) {
	    ++$count_of_A;
	} elsif ($AA eq 'C' ) {
	    ++$count_of_C;
	} elsif ($AA eq 'S' ){
            ++$count_of_S; 
	} elsif ($AA eq 'T' ){
		++$count_of_T;
	} elsif ($AA eq 'P' ){
            ++$count_of_P;
	} elsif ($AA eq 'G' ){
            ++$count_of_G;
	} elsif ($AA eq 'N' ){
            ++$count_of_N;
	} elsif ($AA eq 'D' ){
            ++$count_of_D;
	} elsif ($AA eq 'E' ){
            ++$count_of_E;
	} elsif ($AA eq 'Q' ){
            ++$count_of_Q;
	} elsif ($AA eq 'H' ){
            ++$count_of_H;
	} elsif ($AA eq 'R' ){
            ++$count_of_R;
	} elsif ($AA eq 'K' ){
            ++$count_of_K;
	} elsif ($AA eq 'M' ){
            ++$count_of_M;
	} elsif ($AA eq 'I' ){
            ++$count_of_I;
	} elsif ($AA eq 'L' ){
            ++$count_of_L;
	} elsif ($AA eq 'V' ){
            ++$count_of_V;
	} elsif ($AA eq 'F' ){
            ++$count_of_F;
	} elsif ($AA eq 'Y' ){
            ++$count_of_Y;
	} elsif ($AA eq 'W' ){
            ++$count_of_W;
	}else {
	    print "I don't recognize this $AA\n";
	}
}

my $count_of_Anew = $count_of_A * 4;
my $count_of_Cnew = $count_of_C * 9;
my $count_of_Snew = $count_of_S * 4;
my $count_of_Tnew = $count_of_T * 4;
my $count_of_Pnew = $count_of_P * 7;
my $count_of_Gnew = $count_of_G * 6;
my $count_of_Nnew = $count_of_N * 6;
my $count_of_Dnew = $count_of_D * 6;
my $count_of_Enew = $count_of_E * 5;
my $count_of_Qnew = $count_of_Q * 5;
my $count_of_Hnew = $count_of_H * 8;
my $count_of_Rnew = $count_of_R * 5;
my $count_of_Knew = $count_of_K * 5;
my $count_of_Mnew = $count_of_M * 5;
my $count_of_Inew = $count_of_I * 4;
my $count_of_Lnew = $count_of_L * 4;
my $count_of_Vnew = $count_of_V * 4;
my $count_of_Fnew = $count_of_F * 6;
my $count_of_Ynew = $count_of_Y * 7;
my $count_of_Wnew = $count_of_W * 11;

#If I wanted to know the score for each amino acid
#print "A = $count_of_Anew\n";
#print "C = $count_of_Cnew\n";
#print "S = $count_of_Snew\n";
#print "T = $count_of_Tnew\n";
#print "P = $count_of_Pnew\n";
#print "G = $count_of_Gnew\n";
#print "N = $count_of_Nnew\n";
#print "D = $count_of_Dnew\n";
#print "E = $count_of_Enew\n";
#print "Q = $count_of_Qnew\n";
#print "H = $count_of_Hnew\n";
#print "R = $count_of_Rnew\n";
#print "K = $count_of_Knew\n";
#print "M = $count_of_Mnew\n";
#print "I = $count_of_Inew\n";
#print "L = $count_of_Lnew\n";
#print "V = $count_of_Vnew\n";
#print "F = $count_of_Fnew\n";
#print "Y = $count_of_Ynew\n";
#print "W = $count_of_Wnew\n";

my $totalAA = ($count_of_A + $count_of_C + $count_of_S + $count_of_T + $count_of_P + $count_of_G + $count_of_N + $count_of_D + $count_of_E + $count_of_Q + $count_of_H + $count_of_R + $count_of_K + $count_of_M + $count_of_I + $count_of_L + $count_of_V + $count_of_F + $count_of_Y + $count_of_W);


my $totalscore = ($count_of_Anew + $count_of_Cnew + $count_of_Snew + $count_of_Tnew + $count_of_Pnew + $count_of_Gnew + $count_of_Nnew + $count_of_Dnew + $count_of_Enew + $count_of_Qnew + $count_of_Hnew + $count_of_Rnew + $count_of_Knew + $count_of_Mnew + $count_of_Inew + $count_of_Lnew + $count_of_Vnew + $count_of_Fnew + $count_of_Ynew + $count_of_Wnew); 

print "There are $totalAA total amino acids in this sequence\n";

print "The total max score for this sequence: $totalscore\n"; 

exit;

